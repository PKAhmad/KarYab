import { ReactNode } from "react";

interface PhoneFrameProps {
  children: ReactNode;
}

export function PhoneFrame({ children }: PhoneFrameProps) {
  return (
    <div className="flex items-center justify-center min-h-screen w-full"
      style={{ background: "linear-gradient(135deg, #F0FFF4 0%, #E8F5E9 40%, #F3F4F6 100%)" }}>
      {/* Phone outer shell */}
      <div
        className="relative flex-shrink-0"
        style={{
          width: 375,
          height: 812,
          borderRadius: 50,
          background: "linear-gradient(145deg, #2a2a2a 0%, #1a1a1a 100%)",
          boxShadow: "0 40px 80px rgba(0,0,0,0.35), 0 0 0 1px rgba(255,255,255,0.08), inset 0 0 0 2px rgba(255,255,255,0.05)",
          padding: 12,
        }}
      >
        {/* Volume buttons */}
        <div className="absolute" style={{ left: -4, top: 120, width: 4, height: 32, background: "#333", borderRadius: "2px 0 0 2px" }} />
        <div className="absolute" style={{ left: -4, top: 164, width: 4, height: 56, background: "#333", borderRadius: "2px 0 0 2px" }} />
        <div className="absolute" style={{ left: -4, top: 228, width: 4, height: 56, background: "#333", borderRadius: "2px 0 0 2px" }} />
        {/* Power button */}
        <div className="absolute" style={{ right: -4, top: 168, width: 4, height: 72, background: "#333", borderRadius: "0 2px 2px 0" }} />

        {/* Screen area */}
        <div
          className="relative overflow-hidden flex flex-col"
          style={{
            width: "100%",
            height: "100%",
            borderRadius: 40,
            background: "#ffffff",
          }}
        >
          {/* Dynamic Island / Notch */}
          <div
            className="absolute top-4 left-1/2 -translate-x-1/2 z-50"
            style={{
              width: 120,
              height: 34,
              background: "#111",
              borderRadius: 20,
            }}
          />

          {/* Screen content */}
          <div className="flex flex-col h-full pt-[52px] overflow-hidden">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
