import { useState } from "react";
import {
  Volume2,
  Briefcase,
  FileText,
  CheckCircle2,
  ArrowRight,
  Mic,
} from "lucide-react";

export type AppLanguage = "pashto" | "dari" | "english";

interface WelcomeScreenProps {
  onContinue: (language: AppLanguage) => void;
}

const LANGUAGES = [
  {
    id: "pashto" as AppLanguage,
    name: "Pashto",
    native: "پشتو",
    hasVoice: true,
  },
  {
    id: "dari" as AppLanguage,
    name: "Dari",
    native: "دری",
    hasVoice: true,
  },
  {
    id: "english" as AppLanguage,
    name: "English",
    native: null,
    hasVoice: false,
  },
];

const NEON = "#39FF14";

export function WelcomeScreen({
  onContinue,
}: WelcomeScreenProps) {
  const [selectedLang, setSelectedLang] =
    useState<AppLanguage>("pashto");

  return (
    <div className="flex flex-col h-full bg-white relative overflow-hidden select-none">
      {/* Decorative background orbs */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: -60,
          right: -60,
          width: 200,
          height: 200,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(57,255,20,0.18) 0%, transparent 70%)",
        }}
      />
      <div
        className="absolute pointer-events-none"
        style={{
          top: 80,
          left: -80,
          width: 180,
          height: 180,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(255,140,50,0.12) 0%, transparent 70%)",
        }}
      />

      {/* Help Button */}
      <div className="flex justify-end px-4 mb-1">
        <button
          className="flex items-center gap-1.5 rounded-full px-3 py-1.5 transition-opacity active:opacity-70"
          style={{ background: "#F3F4F6" }}
        >
          <Volume2 size={11} color="#6B7280" />
          <span
            style={{
              fontSize: 11,
              color: "#6B7280",
              fontWeight: 500,
            }}
          >
            Help
          </span>
        </button>
      </div>

      {/* Logo Block */}
      <div
  className="flex flex-col items-center mx-4 pt-4 pb-5 mb-2"
  style={{
    borderRadius: 32,
    backdropFilter: "blur(32px) saturate(200%) brightness(1.08)",
    WebkitBackdropFilter: "blur(32px) saturate(200%) brightness(1.08)",
    background: "rgba(255,255,255,0.08)",
    border: "1.5px solid rgba(255,255,255,0.45)",
    boxShadow: [
      "0 20px 48px rgba(19,219,232,0.12)",
      "0 8px 24px rgba(0,0,0,0.08)",
      "0 1px 0 rgba(255,255,255,0.75) inset",
      "0 -1px 0 rgba(0,0,0,0.04) inset",
      "1px 0 0 rgba(255,255,255,0.35) inset",
      "-1px 0 0 rgba(255,255,255,0.35) inset",
    ].join(", "),
  }}
>
        {/* Logo Icon */}
        <div
          className="flex items-center justify-center mb-3 shadow-xl"
          style={{
            width: 68,
            height: 68,
            borderRadius: 20,
            background:
              "linear-gradient(145deg, #1A1A2E 0%, #2D2D50 100%)",
            boxShadow: `0 8px 24px rgba(57,255,20,0.25), 0 2px 8px rgba(0,0,0,0.2)`,
          }}
        >
          <span
            style={{
              fontSize: 30,
              fontWeight: 800,
              color: "#FFFFFF",
              letterSpacing: -1,
            }}
          >
            K
          </span>
          <span
            style={{
              fontSize: 30,
              fontWeight: 800,
              color: NEON,
              letterSpacing: -1,
              marginLeft: -3,
            }}
          >
            y
          </span>
        </div>

        {/* Brand Name */}
        <div className="flex items-baseline gap-0">
          <span
            style={{
              fontSize: 28,
              fontWeight: 800,
              color: "#1A1A2E",
            }}
          >
            Kar
          </span>
          <span
            style={{
              fontSize: 28,
              fontWeight: 800,
              color: NEON,
            }}
          >
            Yab
          </span>
        </div>
        {/* Dari/Pashto name */}
        <span
          style={{
            fontSize: 15,
            color: "#6B7280",
            fontWeight: 400,
            direction: "rtl",
          }}
        >
          کاریاب
        </span>
        {/* Tagline */}
        <p
          style={{
            fontSize: 12,
            color: "#9CA3AF",
            marginTop: 4,
            textAlign: "center",
          }}
        >
          Find jobs and build your German CV
        </p>
      </div>

      {/* Feature Pills */}
      <div
        className="mx-4 flex justify-around py-3.5 px-2 mb-4"
        style={{
          borderRadius: 24,
          backdropFilter: "blur(28px) saturate(180%)",
          WebkitBackdropFilter: "blur(28px) saturate(180%)",
          background: "rgba(255,255,255,0.22)",
          border: "1.5px solid rgba(255,255,255,0.60)",
          boxShadow:
            "0 8px 32px rgba(57,255,20,0.08), 0 2px 12px rgba(0,0,0,0.06), inset 0 1.5px 0 rgba(255,255,255,0.75)",
        }}
      >
        {[
          {
            icon: <Briefcase size={17} color="#374151" />,
            label: "Job Finder",
          },
          {
            icon: <FileText size={17} color="#374151" />,
            label: "CV Generator",
          },
          {
            icon: <Mic size={17} color="#374151" />,
            label: "Voice Support",
          },
        ].map((f) => (
          <div
            key={f.label}
            className="flex flex-col items-center gap-1.5"
          >
            <div
              className="flex items-center justify-center"
              style={{
                width: 40,
                height: 40,
                borderRadius: 12,
                background: "rgba(255,255,255,0.70)",
                backdropFilter: "blur(14px)",
                WebkitBackdropFilter: "blur(14px)",
                border: "1.5px solid rgba(255,255,255,0.85)",
                boxShadow:
                  "0 4px 16px rgba(0,0,0,0.07), inset 0 1px 0 rgba(255,255,255,0.9)",
              }}
            >
              {f.icon}
            </div>
            <span
              style={{
                fontSize: 10,
                color: "#6B7280",
                fontWeight: 500,
              }}
            >
              {f.label}
            </span>
          </div>
        ))}
      </div>

      {/* Language Selection */}
      <div
        className="px-4 flex-1 mx-4"
        style={{
          borderRadius: 28,
          padding: "16px 14px 18px",
          backdropFilter:
            "blur(32px) saturate(200%) brightness(1.05)",
          WebkitBackdropFilter:
            "blur(32px) saturate(200%) brightness(1.05)",
          background: "rgba(255,255,255,0.80)",
          border: "1.5px solid rgba(255,255,255,0.75)",
          boxShadow: [
            "0 20px 60px rgba(57,255,20,0.22)",
            "0 8px 24px rgba(0,0,0,0.12)",
            "0 2px 6px rgba(0,0,0,0.06)",
            "inset 0 2px 0 rgba(255,255,255,0.90)",
            "inset 0 -1px 0 rgba(0,0,0,0.05)",
            "inset 1px 0 0 rgba(255,255,255,0.60)",
            "inset -1px 0 0 rgba(255,255,255,0.60)",
          ].join(", "),
        }}
      >
        <p
          style={{
            fontSize: 14,
            fontWeight: 700,
            color: "#1A1A2E",
            textAlign: "center",
            marginBottom: 3,
          }}
        >
          Choose your language
        </p>
        <p
          style={{
            fontSize: 11,
            color: "#9CA3AF",
            textAlign: "center",
            marginBottom: 14,
          }}
        >
          We support Pashto, Dari &amp; English
        </p>

        <div className="flex gap-2.5">
          {LANGUAGES.map((lang) => {
            const isSelected = selectedLang === lang.id;
            return (
              <button
                key={lang.id}
                onClick={() => setSelectedLang(lang.id)}
                className="flex-1 relative flex flex-col items-center py-3.5 px-1.5 transition-all active:scale-95"
                style={{
                  borderRadius: 18,
                  minHeight: 100,
                  backdropFilter: "blur(24px) saturate(180%)",
                  WebkitBackdropFilter:
                    "blur(24px) saturate(180%)",
                  background: isSelected
                    ? "rgba(57,255,20,0.12)"
                    : "rgba(255,255,255,0.80)",
                  border: isSelected
                    ? `2px solid ${NEON}`
                    : "1.5px solid rgba(255,255,255,0.65)",
                  boxShadow: isSelected
                    ? `0 8px 32px rgba(57,255,20,0.35), 0 2px 12px rgba(57,255,20,0.18), inset 0 1.5px 0 rgba(255,255,255,0.6)`
                    : "0 4px 20px rgba(0,0,0,0.07), 0 1px 6px rgba(0,0,0,0.04), inset 0 1.5px 0 rgba(255,255,255,0.8)",
                }}
              >
                {isSelected && (
                  <CheckCircle2
                    size={15}
                    color={NEON}
                    style={{
                      position: "absolute",
                      top: 8,
                      right: 8,
                    }}
                  />
                )}

                {/* Icon */}
                {lang.hasVoice ? (
                  <Volume2
                    size={22}
                    color={isSelected ? "#374151" : "#9CA3AF"}
                  />
                ) : (
                  <span
                    style={{
                      fontSize: 22,
                      fontWeight: 800,
                      color: isSelected ? "#374151" : "#9CA3AF",
                      lineHeight: 1,
                    }}
                  >
                    A
                  </span>
                )}

                {/* Language name */}
                <span
                  style={{
                    fontSize: 12,
                    fontWeight: 700,
                    color: "#1A1A2E",
                    marginTop: 6,
                    marginBottom: 2,
                  }}
                >
                  {lang.name}
                </span>

                {/* Native script */}
                {lang.native && (
                  <span
                    style={{
                      fontSize: 11,
                      color: "#6B7280",
                      direction: "rtl",
                    }}
                  >
                    {lang.native}
                  </span>
                )}

                {/* Voice badge */}
                {lang.hasVoice && (
                  <div className="flex items-center gap-0.5 mt-1.5">
                    <Volume2 size={9} color={NEON} />
                    <span
                      style={{
                        fontSize: 9,
                        color: NEON,
                        fontWeight: 600,
                      }}
                    >
                      Voice
                    </span>
                  </div>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Info Box */}
      <div
        className="mx-4 mt-4 flex items-center gap-3"
        style={{
          background: "#F9FAFB",
          borderRadius: 16,
          padding: "10px 14px",
        }}
      >
        <div
          className="flex-shrink-0 flex items-center justify-center"
          style={{
            width: 36,
            height: 36,
            borderRadius: "50%",
            background: `linear-gradient(135deg, ${NEON}, #000000)`,
          }}
        >
          <span style={{ fontSize: 16 }}>🌿</span>
        </div>
        <p
          style={{
            fontSize: 10.5,
            color: "#6B7280",
            lineHeight: 1.5,
          }}
        >
          KarYab helps Afghan workers in Germany find the right
          jobs and create professional CVs that get noticed.
        </p>
      </div>

      {/* Continue Button */}
      <div className="px-4 pb-6 pt-4">
        <button
          onClick={() => onContinue(selectedLang)}
          className="w-full flex items-center justify-center gap-2 transition-transform active:scale-95 px-[10px] py-[0px]"
          style={{
            background:
              "linear-gradient(135deg, #0D0D1A 0%, #1a1a33 100%)",
            borderRadius: 50,
            height: 54,
            boxShadow:
              "0 6px 28px rgba(0,0,26,0.55), 0 2px 8px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.08)",
            border: "1px solid rgba(26,26,80,0.6)",
          }}
        >
          <span
            style={{
              fontSize: 15,
              fontWeight: 700,
              color: "#FFFFFF",
            }}
          >
            Continue
          </span>
          <ArrowRight
            size={18}
            color="#FFFFFF"
            strokeWidth={2.5}
          />
        </button>

        <p
          style={{
            fontSize: 10,
            color: "#9CA3AF",
            textAlign: "center",
            marginTop: 12,
            letterSpacing: 0.3,
          }}
        >
          Your Job. Your CV. Your Future.
        </p>
      </div>
    </div>
  );
}