import { useState } from "react";
import { PhoneFrame } from "./components/PhoneFrame";
import { WelcomeScreen, AppLanguage } from "./components/WelcomeScreen";

type Screen =
  | "welcome"
  | "education"
  | "intro"
  | "questionnaire"
  | "photo"
  | "review"
  | "cv"
  | "jobs"
  | "job-detail"
  | "apply-uneducated"
  | "apply-educated";

export interface AppState {
  language: AppLanguage;
  isEducated: boolean | null;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("welcome");
  const [appState, setAppState] = useState<AppState>({
    language: "pashto",
    isEducated: null,
  });

  const handleWelcomeContinue = (language: AppLanguage) => {
    setAppState((prev) => ({ ...prev, language }));
    // Navigate to next screen (to be implemented)
    // For now just show an alert
    setScreen("education");
  };

  return (
    <PhoneFrame>
      {screen === "welcome" && (
        <WelcomeScreen onContinue={handleWelcomeContinue} />
      )}

      {screen === "education" && (
        <ComingSoon
          screenName="Education Level Screen"
          subtitle="Screen 2 coming next"
          onBack={() => setScreen("welcome")}
        />
      )}
    </PhoneFrame>
  );
}

function ComingSoon({
  screenName,
  subtitle,
  onBack,
}: {
  screenName: string;
  subtitle: string;
  onBack: () => void;
}) {
  return (
    <div className="flex flex-col h-full items-center justify-center bg-white px-8 gap-4">
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center"
        style={{ background: "#39FF14", boxShadow: "0 8px 24px rgba(57,255,20,0.35)" }}
      >
        <span style={{ fontSize: 28 }}>🚧</span>
      </div>
      <div className="text-center">
        <p style={{ fontSize: 16, fontWeight: 700, color: "#1A1A2E" }}>{screenName}</p>
        <p style={{ fontSize: 12, color: "#9CA3AF", marginTop: 4 }}>{subtitle}</p>
      </div>
      <button
        onClick={onBack}
        className="px-6 py-2 rounded-full text-sm font-semibold"
        style={{ background: "#F3F4F6", color: "#374151" }}
      >
        ← Back
      </button>
    </div>
  );
}
